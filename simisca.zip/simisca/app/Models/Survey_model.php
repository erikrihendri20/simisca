<?php

namespace App\Models;

use CodeIgniter\Model;

class Survey_model extends Model
{
    protected $table      = 'lime_survey_423492';
    protected $primaryKey = 'id';

    protected $returnType     = 'array';

    protected $useTimestamps = true;

}
