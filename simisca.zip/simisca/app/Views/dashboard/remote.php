<?= $this->extend('template/dashboard/index'); ?>
<?= $this->section('content'); ?>
            <div class="menu-content">
                <iframe src="http://localhost/limesurvey/index.php/admin/tokens/sa/browse/surveyid/423492" class='w-100' style="height: 500px;" frameborder="0"></iframe>
            </div>
<?= $this->endSection(); ?>