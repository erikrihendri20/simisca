<?= $this->extend('template/dashboard/index'); ?>
<?= $this->section('content'); ?>
<div class="menu-content">
    <div class="card text-light">
        <h1 class="font-weight-bold text-light text-center pt-4">Tentang SIMISCA BPS</h1>
        <div class="card-body">
            <div class="card">
                <h3>Latar Belakang</h3>
                <div class="card-body">
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Non qui porro explicabo, sed, ipsum praesentium repellendus quod sit velit dolorum sint ab, dignissimos quibusdam cum soluta aperiam laborum excepturi. Fugiat.
                    Lorem ipsum, dolor sit amet consectetur adipisicing elit. Totam soluta minus iste sequi quasi autem animi repellat, eaque accusamus adipisci tempore itaque nesciunt distinctio corporis quas similique nostrum veritatis fuga!
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Totam laboriosam doloribus veritatis non saepe vero repudiandae sed, nulla at voluptas. Eligendi a, hic omnis explicabo nihil in laborum harum dolore?
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Doloribus, aspernatur fugit ex ullam necessitatibus delectus quidem repellat iusto impedit illo ratione voluptate velit unde vero. Pariatur adipisci sit rem qui.
                </div>
            </div>
            <div class="card">
                <h3>Tujuan</h3>
                <div class="card-body">
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Non qui porro explicabo, sed, ipsum praesentium repellendus quod sit velit dolorum sint ab, dignissimos quibusdam cum soluta aperiam laborum excepturi. Fugiat.
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Non qui porro explicabo, sed, ipsum praesentium repellendus quod sit velit dolorum sint ab, dignissimos quibusdam cum soluta aperiam laborum excepturi. Fugiat.
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Non qui porro explicabo, sed, ipsum praesentium repellendus quod sit velit dolorum sint ab, dignissimos quibusdam cum soluta aperiam laborum excepturi. Fugiat.
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Non qui porro explicabo, sed, ipsum praesentium repellendus quod sit velit dolorum sint ab, dignissimos quibusdam cum soluta aperiam laborum excepturi. Fugiat.
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Non qui porro explicabo, sed, ipsum praesentium repellendus quod sit velit dolorum sint ab, dignissimos quibusdam cum soluta aperiam laborum excepturi. Fugiat.
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Non qui porro explicabo, sed, ipsum praesentium repellendus quod sit velit dolorum sint ab, dignissimos quibusdam cum soluta aperiam laborum excepturi. Fugiat.
                </div>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection(); ?>